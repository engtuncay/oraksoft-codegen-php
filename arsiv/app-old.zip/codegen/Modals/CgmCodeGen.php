<?php

namespace codegen\Modals;

class CgmCodeGen
{

}